#This script simply adds the prefix to the website entered by the user
#This is designed to improve user experience
#Returns the web prefix and domain name in a proper url format to be used by
#the url search script
def processSite(domain):
    return "https://"+domain